# heatmap-matrix-panel
Grafana d3 heatmap panel with option to color per category change.
