define(["@grafana/data","d3","react"], function(__WEBPACK_EXTERNAL_MODULE__grafana_data__, __WEBPACK_EXTERNAL_MODULE_d3__, __WEBPACK_EXTERNAL_MODULE_react__) { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./module.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./HeatmapPanel.tsx":
/*!**************************!*\
  !*** ./HeatmapPanel.tsx ***!
  \**************************/
/*! exports provided: HeatmapPanel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeatmapPanel", function() { return HeatmapPanel; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! d3 */ "d3");
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(d3__WEBPACK_IMPORTED_MODULE_1__);
// @ts-nocheck


var HeatmapPanel = function HeatmapPanel(_a) {
  var options = _a.options,
      data = _a.data,
      width = _a.width,
      height = _a.height; // -----------------------    CHART CONSTANTS    -----------------------

  var CHART_REQUIRED_FIELDS = {
    pivot: 'pivot'
  };
  var PERCENTAGE_CHANGE_DIRECTION = {
    topToBottom: 'topToBottom',
    bottomToTop: 'bottomToTop'
  };
  var COLOR_CELL_BY = {
    change: 0,
    heatmap: 1
  };
  var COLOR_OPTIONS_SIZE = Object.keys(COLOR_CELL_BY).length; // -----------------------  CHART CONFIGURATION  -----------------------

  var config = {
    background: 'white',
    removeEmptyCols: true,
    changeDirection: options.changeDirection,
    colorBy: COLOR_CELL_BY.change,
    toggleColor: options.toggleColor
  }; // The indices are drawn from top (index 0) to bottom (index dataLen - 1)
  // keeping the original order. There's no option in this plugin to reverse the order.
  // This option is intended to handle the COLOR in which the items will be filled
  // when the reference is per category
  // Note: when a cell is clicked a regular heatmap is drawn toggling this variable effect

  config.referenceChange = config.changeDirection === PERCENTAGE_CHANGE_DIRECTION.bottomToTop ? 1 // next pivot index
  : -1; // previous pivot index
  // ----------------------- BASE DATA ACQUISITION -----------------------

  var frame = data.series[0];
  var dataLen = frame.length; // -----------------------       ACCESSORS      -----------------------

  var pivotAccesor = frame.fields.find(function (field) {
    return field.name === CHART_REQUIRED_FIELDS.pivot;
  });
  var baseCategoryFields = frame.fields.filter(function (field) {
    return field.name !== CHART_REQUIRED_FIELDS.pivot;
  });
  var categoryFields = !config.removeEmptyCols ? baseCategoryFields : baseCategoryFields.filter(function (field) {
    return d3__WEBPACK_IMPORTED_MODULE_1__["sum"](field.values.toArray()) > 0;
  }); // -----------------------      VALIDATIONS     -----------------------

  if (!pivotAccesor) {
    throw new Error("Required fields not present: " + Object.keys(CHART_REQUIRED_FIELDS).join(', '));
  } // -----------------------  CHART FIELD VALUES  -----------------------


  var pivots = pivotAccesor.values.toArray();
  var categories = categoryFields.map(function (field) {
    return field.name;
  });
  var pivotIndices = d3__WEBPACK_IMPORTED_MODULE_1__["range"](dataLen);
  var categoryExtent = d3__WEBPACK_IMPORTED_MODULE_1__["extent"](categoryFields.flatMap(function (field) {
    return d3__WEBPACK_IMPORTED_MODULE_1__["extent"](field.values.toArray());
  })); // -----------------------    CHART DIMENSIONS  -----------------------

  var dimensions = {
    width: width,
    height: height,
    marginTop: 20,
    marginRight: 30,
    marginBottom: 10,
    marginLeft: 40
  };
  dimensions.boundedWidth = dimensions.width - dimensions.marginLeft - dimensions.marginRight;
  dimensions.boundedHeight = dimensions.height - dimensions.marginTop - dimensions.marginBottom; // -----------------------    CHART ELEMENTS    -----------------------
  // COLOR BY VERTICAL CHANGE PERCENTAGE

  var colorByChange = d3__WEBPACK_IMPORTED_MODULE_1__["scaleLinear"]().domain([-1.5, 0, 1.5]).range(['red', 'rgb(250, 248, 193)', 'green']).interpolate(d3__WEBPACK_IMPORTED_MODULE_1__["interpolateRgb"]); // COLOR BY COMPLETE VALUES - PROPER HEATMAP
  // clampling interpolater to avoid using lighter and stronger blues

  var clampColorRange = d3__WEBPACK_IMPORTED_MODULE_1__["interpolate"](0, 0.7);
  var colorAsHeatmap = d3__WEBPACK_IMPORTED_MODULE_1__["scaleSequential"]().domain(categoryExtent).interpolator(function (t) {
    return d3__WEBPACK_IMPORTED_MODULE_1__["interpolateBlues"](clampColorRange(t));
  }); // SCALES

  var x = d3__WEBPACK_IMPORTED_MODULE_1__["scaleBand"]().domain(categories).range([0, dimensions.boundedWidth]).padding(0.2);
  var y = d3__WEBPACK_IMPORTED_MODULE_1__["scaleBand"]().domain(pivots).range([0, dimensions.boundedHeight]).padding(0.2); // AXIS

  var xAxis = function xAxis(g) {
    return g.call(d3__WEBPACK_IMPORTED_MODULE_1__["axisTop"](x).tickSize(0).tickSizeOuter(0)).call(function (g) {
      return g.select('.domain').remove();
    }).selectAll('text').attr('dy', '.5em').style('text-anchor', 'midle');
  };

  var yAxis = function yAxis(g) {
    return g.call(d3__WEBPACK_IMPORTED_MODULE_1__["axisLeft"](y).tickSize(0).tickPadding(4)).call(function (g) {
      return g.select('.domain').remove();
    }).selectAll('text').attr('x', 5);
  }; // VALUE FORMATING


  var formatValue = function formatValue(_a) {
    var category = _a.category,
        pivotIndex = _a.pivotIndex;
    return parseFloat(d3__WEBPACK_IMPORTED_MODULE_1__["format"]('.2f')(categoryFields.find(function (field) {
      return field.name === category;
    }).values.get(pivotIndex)));
  };

  var getValues = function getValues(_a) {
    var category = _a.category,
        pivotIndex = _a.pivotIndex;
    var referenceIndex = pivotIndex + config.referenceChange;
    var currentValue = formatValue({
      category: category,
      pivotIndex: pivotIndex
    });
    var referenceValue = formatValue({
      category: category,
      pivotIndex: referenceIndex
    }) || 0;
    var change = (currentValue - referenceValue) / referenceValue;
    return {
      currentValue: currentValue,
      referenceValue: referenceValue,
      change: change
    };
  }; // CHART


  var chart = function chart(svg) {
    // SVG STYLING
    svg.style('background-color', config.background); // BOUNDS

    var bounds = svg.append('g').attr('transform', "translate(" + dimensions.marginLeft + ", " + dimensions.marginTop + ")"); // MATRIX

    bounds.selectAll('g').data(pivotIndices).join('g').each(function (pivotIndex, i, nodes) {
      // CONSTANTS PER GROUP
      var itemPositionY = y(pivotAccesor.values.get(pivotIndex)); // HELPERS

      var colorChange = function colorChange(d) {
        var _a = getValues(d),
            currentValue = _a.currentValue,
            referenceValue = _a.referenceValue,
            change = _a.change; // clamping change to avoid using the stronger tone generated by interpolator


        var clampedChange = change > 1 ? 1 : change < -1 ? -1 : change;
        return currentValue === 0 ? colorByChange(0) : referenceValue === 0 ? colorByChange(0.5) : colorByChange(clampedChange);
      };

      var colorHeatmap = function colorHeatmap(d) {
        var currentValue = getValues(d).currentValue;
        return colorAsHeatmap(currentValue);
      };

      var getColor = function getColor(d) {
        switch (config.colorBy) {
          case COLOR_CELL_BY.change:
            return colorChange(d);

          case COLOR_CELL_BY.heatmap:
            return colorHeatmap(d);

          default:
            break;
        }
      };

      var toggleColoring = function toggleColoring(_) {
        if (!config.toggleColor) {
          return;
        }

        config.colorBy = (config.colorBy + 1) % COLOR_OPTIONS_SIZE;
        bounds.selectAll('.matrix-cell').transition().duration(500).attr('fill', getColor);
      }; // DRAWING


      var item = d3__WEBPACK_IMPORTED_MODULE_1__["select"](nodes[i]).selectAll('g').data(categories.map(function (category) {
        return {
          category: category,
          pivotIndex: pivotIndex
        };
      })).join('g'); // CELLS

      item.append('rect').attr('class', 'matrix-cell').attr('x', function (d) {
        return x(d.category);
      }).attr('y', itemPositionY).attr('rx', 2).attr('ry', 2).attr('width', x.bandwidth()).attr('height', y.bandwidth()).on('click', toggleColoring).attr('fill', getColor).append('title').text(formatValue); // VALUES

      item.append('text').attr('font-size', 10).attr('pointer-events', 'none').attr('text-anchor', 'middle') // .attr('x', category => x(category) + x.bandwidth() / 2)
      // .attr('y', itemPositionY + y.bandwidth() / 2)
      .call(function (text) {
        return text.append('tspan').attr('x', function (d) {
          return x(d.category) + x.bandwidth() / 2;
        }).attr('y', itemPositionY + y.bandwidth() / 2).each(function (d, i, nodes) {
          var _a = getValues(d),
              currentValue = _a.currentValue,
              referenceValue = _a.referenceValue;

          d3__WEBPACK_IMPORTED_MODULE_1__["select"](nodes[i]) // move up a little => room for percentage change
          .attr('dy', currentValue && referenceValue ? '-0.4em' : '.35em') // display totals if total > 0
          .text(currentValue ? d3__WEBPACK_IMPORTED_MODULE_1__["format"]('.3~s')(currentValue) : '-');
        });
      }).call(function (text) {
        return text.append('tspan').attr('x', function (d) {
          return x(d.category) + x.bandwidth() / 2;
        }).attr('y', itemPositionY + y.bandwidth() / 2).each(function (d, i, nodes) {
          var _a = getValues(d),
              currentValue = _a.currentValue,
              referenceValue = _a.referenceValue,
              change = _a.change;

          if (currentValue && referenceValue) {
            // display percentage change bellow totals
            d3__WEBPACK_IMPORTED_MODULE_1__["select"](nodes[i]).attr('dy', '1em').text(d3__WEBPACK_IMPORTED_MODULE_1__["format"]('.1%')(change));
          }
        });
      });
    }); // AXIS

    bounds.append('g').call(xAxis);
    bounds.append('g').call(yAxis);
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", {
    viewBox: "0 0 " + dimensions.width + " " + dimensions.height,
    ref: function ref(node) {
      d3__WEBPACK_IMPORTED_MODULE_1__["select"](node).selectAll('*').remove();
      d3__WEBPACK_IMPORTED_MODULE_1__["select"](node).call(chart);
    }
  });
};

/***/ }),

/***/ "./module.ts":
/*!*******************!*\
  !*** ./module.ts ***!
  \*******************/
/*! exports provided: plugin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "plugin", function() { return plugin; });
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @grafana/data */ "@grafana/data");
/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_grafana_data__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _HeatmapPanel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./HeatmapPanel */ "./HeatmapPanel.tsx");


var plugin = new _grafana_data__WEBPACK_IMPORTED_MODULE_0__["PanelPlugin"](_HeatmapPanel__WEBPACK_IMPORTED_MODULE_1__["HeatmapPanel"]).setPanelOptions(function (builder) {
  return builder.addSelect({
    path: 'changeDirection',
    name: 'Change Direction',
    defaultValue: 'bottomToTop',
    settings: {
      options: [{
        value: 'topToBottom',
        label: 'Top to Bottom'
      }, {
        value: 'bottomToTop',
        label: 'Bottom to Top'
      }]
    }
  }).addBooleanSwitch({
    path: 'toggleColor',
    name: 'Toggle Color on click',
    defaultValue: true
  });
});

/***/ }),

/***/ "@grafana/data":
/*!********************************!*\
  !*** external "@grafana/data" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_data__;

/***/ }),

/***/ "d3":
/*!*********************!*\
  !*** external "d3" ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_d3__;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_react__;

/***/ })

/******/ })});;
//# sourceMappingURL=module.js.map